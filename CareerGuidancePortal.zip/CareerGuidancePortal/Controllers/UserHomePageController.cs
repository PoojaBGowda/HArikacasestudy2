﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CareerGuidancePortal.Controllers
{
    public class UserHomePageController : Controller
    {
        // GET: UserHomePage
        public ActionResult Home()
        {
            return View();
        }
    }
}